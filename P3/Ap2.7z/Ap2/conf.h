
void config(void);
void init_leds(void);
