#include "stm32f4xx_hal.h"


#ifndef _THALARM_H
#define _THALARM_H

int Init_ThAlarm(void);


#endif