#include "stm32f4xx_hal.h"

#ifndef _THLCD_H
#define _THLCD_H

int Init_ThLCD(void);


#endif
